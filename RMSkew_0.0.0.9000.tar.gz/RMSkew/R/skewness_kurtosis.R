#' Skewness and Kurtosis
#' 
#' @description 
#' Compute skewness and kurtosis for a given error distribution.
#' Conduct Kolmogorov-Smirnov test for normality assumption and Wilcox signed rank test for
#' symmetric assumption
#' 
#' 
# 
# library(e1071)
# library(symmetry)
# source("E://课题//Completed//2025 Asymmetric Mediation Analysis//Rcode//DGPs.R")
# data <- DGP("m.t1e", "norm-asy,r=0.3", 200)
# rlm1 <- rlmskew(m ~ x, data = data, loss = "AT")
# rlm2 <- rlmskew(y ~ x + m, data = data, loss = "AT")
# hat.m <- coef(rlm2)["m"]
# hat.x <- coef(rlm1)["x"]
# ide <- hat.x * hat.m
# se.m <- summary(rlm2)$coefficients["m","Std. Error"]
# se.x <- summary(rlm1)$coefficients["x","Std. Error"]
# se.sobel <- sqrt((hat.x * se.m)^2 + (hat.m * se.x)^2)
# ci <- c(ide - qnorm(0.975) * se.sobel, ide + qnorm(0.975) * se.sobel)
# names(ci) <- NULL
# ci
# # x <- rnorm(10)
# # library(boot)
# # boot(x, statistic = )
# 
# ls1 <- lm(m ~ x, data = data)
# ls2 <- lm(y ~ x + m, data = data)
# hat.m <- coef(rlm2)["m"]
# hat.x <- coef(rlm2)["x"]
# ide <- hat.x * hat.m
# se.m <- summary(rlm2)$coefficients["m","Std. Error"]
# se.x <- summary(rlm1)$coefficients["x","Std. Error"]
# se.sobel <- sqrt((hat.x * se.m)^2 + (hat.m * se.x)^2)
# c(ide - qnorm(0.975) * se.sobel, ide + qnorm(0.975) * se.sobel)
# 
# round(skewness(rlm1$residuals), 3)
# round(kurtosis(rlm1$residuals),3)
# symmetry_test(rlm1$residuals, "MOI", k = 2)
# wilcox.test(rlm1$residuals, mu = 0)









