#' The Laplace (Double Exponential) Distribution
#'
#' @description
#' Density, distribution function, quantile function and random generation
#' for the Laplace (double exponential) distribution with location parameter
#' \code{location} and scale parameter \code{scale}.
#'
#' @details
#' The Laplace distribution has density
#' \deqn{f(x) = \frac{1}{2b} \exp\left(-\frac{|x - \mu|}{b}\right)}
#' where \eqn{\mu} is the location parameter and \eqn{b > 0} is the scale parameter.
#'
#' @param x,q vector of quantiles.
#' @param p vector of probabilities.
#' @param n number of observations.
#' @param location vector of location parameters (mean/median/mode).
#' @param scale vector of scale parameters (must be positive).
#' @param log,log.p logical; if TRUE, probabilities p are given as log(p).
#' @param lower.tail logical; if TRUE (default), probabilities are \eqn{P[X \le x]},
#'                   otherwise, \eqn{P[X > x]}.
#'
#' @return
#' \code{dlaplace} gives the density,
#' \code{plaplace} gives the distribution function,
#' \code{qlaplace} gives the quantile function, and
#' \code{rlaplace} generates random deviates.
#'
#' @name Laplace
#' @aliases Laplace dlaplace plaplace qlaplace rlaplace
#' @family distribution
#'
#' @examples
#' ## Basic usage
#' dlaplace(0)          # Density at 0
#' plaplace(1)          # \eqn{P(X \le 1)}
#' qlaplace(0.95)       # 95% quantile
#' rlaplace(5)          # 5 random numbers
NULL

#' @rdname Laplace
#' @export
dlaplace <- function(x, location = 0, scale = 1, log = FALSE) {
  if (!is.numeric(scale) || any(scale <= 0))
    stop("scale must be positive")
  
  z <- abs(x - location) / scale
  dens <- exp(-z) / (2 * scale)
  
  if (log) dens <- log(dens)
  dens
}

#' @rdname Laplace
#' @export
plaplace <- function(q, location = 0, scale = 1, lower.tail = TRUE, log.p = FALSE) {
  if (!is.numeric(scale) || any(scale <= 0))
    stop("scale must be positive")
  
  z <- (q - location) / scale
  p <- ifelse(z <= 0, 0.5 * exp(z), 1 - 0.5 * exp(-z))
  
  if (!lower.tail) p <- 1 - p
  if (log.p) p <- log(p)
  p
}

#' @rdname Laplace
#' @export
qlaplace <- function(p, location = 0, scale = 1, lower.tail = TRUE, log.p = FALSE) {
  if (!is.numeric(scale) || any(scale <= 0))
    stop("scale must be positive")
  
  if (log.p) p <- exp(p)
  if (!lower.tail) p <- 1 - p
  
  if (any(p < 0 | p > 1, na.rm = TRUE))
    stop("p must be between 0 and 1")
  
  ifelse(p <= 0.5,
         location + scale * log(2 * p),
         location - scale * log(2 * (1 - p)))
}

#' @rdname Laplace
#' @export
rlaplace <- function(n, location = 0, scale = 1) {
  if (!is.numeric(scale) || any(scale <= 0))
    stop("scale must be positive")
  
  u <- runif(n)
  ifelse(u <= 0.5,
         location + scale * log(2 * u),
         location - scale * log(2 * (1 - u)))
}