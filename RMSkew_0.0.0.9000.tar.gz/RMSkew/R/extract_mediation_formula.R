#' Internal mediation formula parsers
#'
#' @description
#'
#'
#' \code{m()} and its wrappers \code{parallel_m()} and \code{serial_m()}
#' create an object of hypothesized mediators, while \code{covariates()}
#' creates an object of control variables.  Usually, these are used in a
#' formula specifying a mediation model.
#'
#' \code{m()} and \code{covariates()} are essentially wrappers for
#' \code{\link[base]{cbind}()} with a specific class prepended to the
#' class(es) of the resulting object.
#'
#' \code{parallel_m()} and \code{serial_m()} are wrappers for \code{m()} with
#' the respective value for argument \code{.model}.
#'
#' @param \dots  variables are supplied as arguments, as usual separated by a
#' comma.
#' @param .model  a character string specifying the type of model in case of
#' multiple mediators.  Possible values are \code{"parallel"} (the default) for
#' the parallel multiple mediator model, or \code{"serial"} for the serial
#' multiple mediator model.
#'
#' @return \code{m()} returns an object inheriting from class
#' \code{"mediators"} (with subclass \code{"parallel_mediators"} or
#' \code{"serial_mediators"} as specified by argument \code{.model}),
#' and \code{covariates()} returns an object of class \code{"covariates"}.
#' Typically, these inherit from class \code{"matrix"}.
#'
#' @author Xiujin Peng
#'
#' @references
#' Alfons A, Ateş NY, & Groenen PJF (2022). Robust mediation analysis: The R Package robmed.
#' *Journal of Statistical Software*, 103(13), 1–45. \doi{10.18637/jss.v103.i13}.
#'
#' Peng X., Wang W.W., & Zhao S.L. (2026) Robust mediation analysis with asymmetric
#' data. *Submitted*
#'
#'
#' @seealso \code{\link{fit_skew_mediation}()}, \code{\link{test_skew_mediation}()}
#'
#' @examples
#' data(LPACOG)
#'
#' fit_skew_mediation(cf ~ m(lpa) + pc + covariates(age,sex,race,educ,inc,pses,limit),
#'               data = LPACOG, loss = "AT", tuning = "asy")
#'
#'
#' @export
m <- function(..., .model = c("parallel", "serial")) {
  # initializations
  .model <- match.arg(.model)
  # This is a bit of a hack: returning a data frame would cause an error
  # with model.frame() in fit_mediation().  Instead, use cbind() to create
  # a matrix and store information on variable types as arguments.
  out <- cbind(...)
  # retrieve information on variable types
  df <- data.frame(..., check.names = FALSE, stringsAsFactors = FALSE)
  classes <- lapply(df, class)
  levels <- lapply(df, function(x) {
    if (is.factor(x)) levels(x)
  })
  # add class
  class(out) <- c(paste(.model, "mediators", sep = "_"),
                  "mediators", class(out))
  # add information on variable types as attributes
  attr(out, "column_types") <- classes
  attr(out, "factor_levels") <- levels
  # return object
  out
}


#' @rdname m
#' @export

parallel_m <- function(...) m(..., .model = "parallel")


#' @rdname m
#' @export

serial_m <- function(...) m(..., .model = "serial")


#' @rdname m
#' @export

covariates <- function(...) {
  # This is a bit of a hack: returning a data frame would cause an error
  # with model.frame() in fit_mediation().  Instead, use cbind() to create
  # a matrix and store information on variable types as arguments.
  out <- cbind(...)
  # retrieve information on variable types
  df <- data.frame(..., check.names = FALSE, stringsAsFactors = FALSE)
  classes <- lapply(df, class)
  levels <- lapply(df, function(x) {
    if (is.factor(x)) levels(x)
  })
  # add class
  class(out) <- c("covariates", class(out))
  # add information on variable types as attributes
  attr(out, "column_types") <- classes
  attr(out, "factor_levels") <- levels
  # return object
  out
}

#' Extract and Structure Mediation Model Components from Formula
#'
#' @description
#' Parses a mediation model formula to extract and structure all model components,
#' including independent variable(s), mediator(s), outcome, and covariates.
#' This is a critical preprocessing step for the \code{\link{fit_skew_mediation}} function.
#'
#' @details
#' The function processes a specially formatted formula to extract mediation model
#' components. It supports two types of mediation models:
#' \itemize{
#'   \item \strong{Parallel mediation}: Multiple mediators independently affect the outcome
#'   \item \strong{Serial mediation}: Mediators are arranged in a causal sequence
#' }
#'
#' The formula must use specific syntax to identify mediators and covariates:
#' \itemize{
#'   \item Mediators are specified using \code{m()}
#'   \item Covariates are specified using \code{covariates()} (optional)
#'   \item The outcome variable is specified on the left side of the formula
#'   \item Independent variables are specified on the right side (outside of \code{m()} and \code{covariates()})
#' }
#'
#' @section Formula Syntax:
#' The function expects formulas in one of these formats:
#' \preformatted{
#' # Parallel mediation with covariates
#' outcome ~ independent_var + m(mediator1, mediator2) + covariates(age, gender)
#'
#' # Serial mediation without covariates
#' outcome ~ independent_var + m(mediator1, mediator2)
#'
#' # Single mediator model
#' outcome ~ treatment + m(mediator) + covariates(age, education)
#' }
#'
#' @param formula A model formula specifying the mediation structure.
#' See 'Formula Syntax' section for detailed format requirements.
#' @param data A data frame containing the variables specified in the formula.
#' @param ... Additional arguments passed to \code{\link{model.frame}}.
#'
#' @return
#' A list with the following components:
#' \describe{
#'   \item{model}{Character string indicating the model type: "parallel" or "serial"}
#'   \item{data}{Processed data frame with all variables}
#'   \item{y}{Character string naming the outcome variable}
#'   \item{m}{Character vector naming the mediator variable(s)}
#'   \item{x}{Character vector naming the independent variable(s)}
#'   \item{covariates}{Character vector naming the covariate(s), or \code{NULL} if none}
#'   \item{formula_mx}{List of formulas for mediator regressions (M ~ X)}
#'   \item{formula_ymx}{List of formulas for outcome regression with mediators (Y ~ M + X)}
#'   \item{formula_yx}{List of formulas for total effect regression (Y ~ X)}
#' }
#'
#' @examples
#' data(LPACOG)
#' formula1 <- cf ~ m(lpa) + pc + covariates(age, sex)
#' extract_mediation_formula(formula = formula1, data = LPACOG)
#'
#' @seealso
#' \code{\link{fit_skew_mediation}} for fitting the mediation model after formula extraction.
#' \code{\link{m}} and \code{\link{covariates}} for helper functions to specify
#' mediators and covariates in formulas.
#'
#' @export
extract_mediation_formula <- function(formula, data, ...){
  mf <- match.call(expand.dots = FALSE)
  m <- match(c("formula", "data"), names(mf), 0)
  mf <- mf[c(1, m)]
  mf$drop.unused.levels <- TRUE
  mf[[1]] <- as.name("model.frame")
  mf <- eval(mf, parent.frame())
  mt <- attr(mf, "terms")
  ## make sure that there are no interaction terms
  ord <- attr(mt, "order")
  if (length(ord) > 0 && any(ord > 1)) {
    stop("interaction terms are not implemented for mediation models")
  }
  # make sure that dependent variable is specified
  if (attr(mt, "response") == 0) {
    stop("no dependent variable specified in formula")
  }
  d <- dim(mf[[1]])
  if (!is.null(d) && d[2] > 1) {
    stop("only one dependent variable allowed in formula")
  }
  index_y <- 1L
  y <- names(mf)[index_y]
  # make sure that mediators are specified
  index_m <- which(sapply(mf, inherits, what = "mediators"))
  if (length(index_m) == 0) {
    stop("mediators must be specified using m() in the formula")
  } else if (length(index_m) > 1) {
    stop("use m() only once in the formula to specify all mediators")
  }
  m <- colnames(mf[[index_m]])
  if (inherits(mf[[index_m]], "serial_mediators")) model <- "serial"
  else model <- "parallel"
  # check if covariates are specified
  index_covariates <- which(sapply(mf, inherits, "covariates"))
  if (length(index_covariates) > 1) {
    stop("use covariates() only once in the formula to specify all covariates")
  }
  have_covariates <- length(index_covariates) > 0L
  if(have_covariates) {
    covariates <- colnames(mf[[index_covariates]])
  } else{
    covariates <- NULL
  }
  # make sure that independent variable is specified
  if (length(mf) == (2 + have_covariates)) {
    stop("no independent variable specified in formula")
  }
  index_x <- setdiff(seq.int(2, dim(mf)[2]), c(index_m, index_covariates))
  x <- names(mf)[index_x]
  # prepare to rebuild data frame
  mf <- as.list(mf)
  names(mf)[c(index_m, index_covariates)] <- ""  # ensure the correct names
  mf[[index_m]] <- as.data.frame(mf[[index_m]])
  if (have_covariates) {
    mf[[index_covariates]] <- as.data.frame(mf[[index_covariates]])
  }
  # add additional arguments to be passed to data.frame()
  mf$check.names <- FALSE
  mf$stringsAsFactors <- TRUE
  # rebuild data frame
  data <- do.call(data.frame, mf)
  # check model
  p_m <- length(m)
  p_x <- length(x)
  if (model == "serial" && p_m > 3){
    stop("serial multiple mediator model not implemented for ",
         "more than 3 hypothesized mediators")
  }
  # define predictors for mx, yx, ymx regression model
  predictors_mx <- vector("list", p_m)
  if(model == "serial"){
    predictors_mx[[1L]] <- c(x, covariates)
    for (j in seq_len(p_m-1L)) {
      predictors_mx[[j+1L]] <- c(x, covariates, m[seq_len(j)])
    }
  }else {
    predictors_mx <- replicate(p_m, c(x, covariates), simplify = FALSE)
  }
  predictors_ymx <- c(x, m, covariates)
  predictors_yx <- c(x, covariates)
  #construct formula for various regression models
  formula_yx <- list(reformulate(predictors_yx, response = y))
  formula_ymx <- list(reformulate(predictors_ymx, response = y))
  formula_mx <- mapply(reformulate, predictors_mx, m)
  names(formula_yx) <- y
  names(formula_ymx) <- y
  names(formula_mx) <- m
  list(model = model, data = data, y = y, m = m, x = x, covariates = covariates,
       formula_mx = formula_mx, formula_ymx = formula_ymx,
       formula_yx = formula_yx)
}

