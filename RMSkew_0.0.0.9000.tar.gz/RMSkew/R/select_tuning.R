#' Select tuning parameters
#'
#' @description
#' Select tuning parameters for asymmetric Huber or Tukey loss functions based on the
#' efficiency factor which comes from the asymptotic variance
#' formula of slope parameters.
#'
#' @details
#' The asymptotic efficiency of an M-estimator depends on the efficiency factor:
#' \deqn{\tau = \frac{\mathrm{E}[\psi^2(\epsilon/\sigma;k_1,k_2)]}{(\mathrm{E}[\psi^\prime(\epsilon/\sigma;k_1,k_2)])^2}}
#' where \eqn{\epsilon} are residuals and \eqn{\sigma} is the scale parameter.
#'
#' This function implements a grid search to find tuning parameters \eqn{(k_1, k_2)}
#' that minimize \eqn{\tau}.
#'
#' The empirical efficiency factor is computed as:
#' \deqn{\hat{\tau}(k_1,k_2)=\frac{n^{-1}\sum_{i=1}^{n}\psi^2(\hat{\epsilon}_i/\hat{\sigma};k_1,k_2)}{
#' (n^{-1}\sum_{i=1}^{n}\psi^{\prime}(\hat{\epsilon}_i/\hat{\sigma};k_1,k_2))^2}}
#' where \eqn{\hat{\epsilon}_i} are estimated residuals and \eqn{\hat{\sigma}} is a robust scale estimate.
#'
#' @name select_tuning
#' @aliases select_tuning compute_tau
#'
#' @param err Numeric vector of residuals (or standardized residuals).
#' @param loss Character string specifying the loss function type:
#'   \itemize{
#'     \item \code{"H"}: Symmetric Huber loss
#'     \item \code{"AH"}: Asymmetric Huber loss
#'     \item \code{"T"}: Symmetric Tukey loss
#'     \item \code{"AT"}: Asymmetric Tukey loss
#'   }
#' @param k1 Left tuning parameter for asymmetric Huber or Tukey loss.
#' @param k2 Right tuning parameter for asymmetric Huber or Tukey loss.
#' @param k Tuning parameter for symmetric Huber or Tukey loss.
#' @param ini Starting value for the tuning parameter grid (default 0.1).
#' @param len Step size for the tuning parameter grid (default 0.1).
#' @param x Numeric vector of (standardized) residuals (for \code{compute_tau}).
#'
#' @return
#' For \code{select_tuning}:
#' \itemize{
#'   \item \code{k.sel} or \code{k1.sel, k2.sel}: Selected tuning parameter(s)
#'   \item \code{tau.hat}: Estimated efficiency factor at selected parameters
#' }
#'
#' For \code{compute_tau}: Numeric value of the estimated efficiency factor \eqn{\hat{\tau}}
#' for the given tuning parameter(s) \eqn{k} or \eqn{k_1} and \eqn{k_2}.
#'
#' @seealso
#' \code{\link{psi}} for the psi functions used in efficiency calculations.
#' \code{\link{Dpsi}} for the derivative of psi functions.
#'
#' @export
NULL

#' @rdname select_tuning
#' @export
select_tuning <- function(err, loss = c("H", "AH", "T", "AT"), ini = 0.1, len = 0.1){
  if(loss == "H"){
    k <- seq(ini, 3, by = len)
    tau.value <- sapply(k, function(k) compute_tau(x = err, loss = "H", k = k))
    ind <- which.min(tau.value)
    tau.sel <- tau.value[ind]
    k.sel <- k[ind]
    return(list(k.sel = k.sel, tau.hat = tau.sel))
  }else if(loss == "AH"){
    k1 <- seq(ini, 3, by = len)
    k2 <- k1
    grid <- expand.grid(k1 = k1, k2 = k2)
    tau.value <- mapply(function(k1, k2){
      compute_tau(x = err, loss = "AH", k1, k2)}, k1 = grid$k1, k2 = grid$k2)
    ind <- which.min(tau.value)
    tau.sel <- tau.value[ind]
    k1.sel <- grid$k1[ind]
    k2.sel <- grid$k2[ind]
    return(list(tau.hat = tau.sel, k1.sel = k1.sel, k2.sel = k2.sel))
  }else if(loss == "T"){
    k <- seq(ini, 6, by = len)
    tau.value <- sapply(k, function(k) compute_tau(x = err, loss = "T", k = k))
    ind <- which.min(tau.value)
    tau.sel <- tau.value[ind]
    k.sel <- k[ind]
    return(list(k.sel = k.sel, tau.hat = tau.sel))
  }else{
    k1 <- seq(ini, 6, len)
    k2 <- k1
    grid <- expand.grid(k1 = k1, k2 = k2)
    tau.value <- mapply(function(k1, k2){
      compute_tau(x = err, loss = "AT", k1, k2)}, k1 = grid$k1, k2 = grid$k2)
    ind <- which.min(tau.value)
    tau.sel <- tau.value[ind]
    k1.sel <- grid$k1[ind]
    k2.sel <- grid$k2[ind]
    return(list(tau.hat = tau.sel, k1.sel = k1.sel, k2.sel = k2.sel))
  }
}

#' @rdname select_tuning
#' @export
compute_tau <- function(x, loss = c("H", "AH", "T", "AT"), k1 = NULL, k2 = NULL, k = NULL){
  if (loss == "H") {
    A = mean(psi(x, loss = "H", k = k)^2)
    B = mean(Dpsi(x, loss = "H", k = k))
  } else if (loss == "AH") {
    A = mean(psi(x, loss = "AH", k1 = k1, k2 = k2)^2)
    B = mean(Dpsi(x, loss = "AH", k1 = k1, k2 = k2))
  } else if (loss == "T"){
    A = mean(psi(x, loss = "T", k = k)^2)
    B = mean(Dpsi(x, loss = "T", k = k))
  } else if (loss == "AT"){
    A = mean(psi(x, loss = "AT", k1, k2)^2)
    B = mean(Dpsi(x, loss = "AT", k1, k2))
  }
  tau.hat = A / B^2
  return(tau.hat)
}

