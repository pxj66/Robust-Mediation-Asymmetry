#' Robust and efficient linear model for skewed data
#'
#' @description
#' Perform robust and efficient regression for skewed data
#'
#' @details
#' 1. Using asymmetric Huber or Tukey loss
#' 2. Select tuning parameters
#' 3. Iteratively reweighted least squares algorithm
#'
#' @param formula Formula used for conducting regression
#' @param data Data set
#' @param loss Character string specifying the loss function type:
#' \itemize{
#'  \item \code{"AH"}: Asymmetric Huber loss
#'  \item \code{"AT"}: Asymmetric Tukey loss
#'  \item \code{"H"}: Symmetric Huber loss
#'  \item \code{"T"}: Symmetric Tukey loss
#' }
#' @param tuning Methods used for selecting tuning parameters
#' \itemize{
#'  \item \code{"asy"}: Asymptotic variance formula criterion is used
#'  \item \code{"fixed"}: Fixed tuning parameters are used. For asymmetric and
#'  symmetric Huber loss, the default value is 1.345. For asymmetric and symmetric
#'  Tukey loss, the default value is 4.685.
#' }
#' @param scale Method used for estimating scale parameter. Default method is the
#' median absolute deviation estimator.
#' @param itmax Maximum number of iterations.
#' @param acc The accuracy required to stop iteration.
#' @param \dots Tuning parameters \code{k} or \code{k1, k2}.
#' @param ini Starting value for the tuning parameter grid (default 0.1).
#' @param len Step size for the tuning parameter grid (default 0.1).
#'
#' @return An object of class \code{"rlmskew"} containing:
#' \item{coefficients}{Estimated regression coefficients}
#' \item{residuals}{Model residuals}
#' \item{fitted.values}{Fitted values}
#' \item{loss.type}{Type of loss function used}
#' \item{tuning.method}{Tuning method used}
#' \item{tuning.parameters}{Selected tuning parameters}
#' \item{scale.estimate}{Scale estimate}
#' \item{tau.hat}{Efficiency factor estimate}
#' \item{weights}{Final weights}
#' \item{converged}{Logical indicating convergence}
#' \item{iterations}{Number of iterations used}
#' \item{coefficients.matrix}{Matrix of coefficients with standard errors and p-values}
#'
#' @examples
#' \dontrun{
#' # Example using asymmetric Huber loss with automatic tuning
#' data(mtcars)
#' model <- rlmskew(mpg ~ wt + hp, data = mtcars, loss = "AH", tuning = "asy")
#' summary(model)
#'
#' # Example with user-specified tuning parameter
#' model2 <- rlmskew(mpg ~ wt + hp, data = mtcars, loss = "H", k = 2.0)
#' }
#'
#' @export
rlmskew <- function(formula, data, loss = c("AH", "AT", "H", "T"),
                    tuning = c("asy", "fixed"), ini = 1, len = 0.1,
                    scale = c("MAD"), itmax = 20, acc = 1e-8, ...) {

  require(quantreg)

  call <- match.call(expand.dots = FALSE)

  tuning.test <- "tuning" %in% names(call)
  loss.test <- "loss" %in% names(call)
  ini.test <- "ini" %in% names(call)

  loss <- match.arg(loss)
  tuning <- match.arg(tuning)
  scale <- match.arg(scale)

  if (loss %in% c("T", "AT")) {
    if(!ini.test){
      ini = 1
    }
    lad <- rlmskew(formula = formula, data = data, loss = "AH",
                   tuning = "asy", ini = ini, ...)
    end = 6
  }else{
    if(!ini.test){
      ini = 0.5
    }
    lad <- rq(formula = formula, data = data)
    end = 3
  }

  y.call <- all.vars(terms(formula, data = data))[1]
  y <- data[[y.call]]
  X <- model.matrix(formula, data)
  n <- nrow(data)
  p <- ncol(X)
  coeff0 <- coef(lad)
  res0 <- resid(lad)
  sigma0 <- mad(res0)

  user.args <- list(...)
  k.test <- "k" %in% names(user.args)
  k1.test <- "k1" %in% names(user.args)
  k2.test <- "k2" %in% names(user.args)

  if (loss == "H") {
    if (k.test) {
      k <- user.args$k
      tuning <- "user"
    } else if (tuning.test && tuning == "fixed") {
      k <- 1.345
    } else {
      tuning <- "asy"
      tun.res <- select_tuning(res0/sigma0, loss = loss, ini = ini, len = len)
      k <- tun.res$k.sel
      if(any(k1.test, k2.test)){
        warning("Tuning parameters are defined but unused. \n  Please provide 'k' for Huber loss.")
      }
    }
    k.obj <- list(k = k)
    w <- function(x) compute_weight(x, loss = loss, k = k)
    tau <- function(x) compute_tau(x, loss = loss, k = k)

  } else if (loss == "T") {
    if (k.test) {
      k <- user.args$k
      tuning <- "user"
    } else if (tuning.test && tuning == "fixed") {
      k <- 4.685
    } else {
      tuning <- "asy"
      tun.res <- select_tuning(res0/sigma0, loss = loss, ini = ini, len = len)
      k <- tun.res$k.sel
      if(any(k1.test, k2.test)){
        warning("Tuning parameters are defined but unused. \n  Please provide 'k' for Tukey loss.")
      }
    }
    k.obj <- list(k = k)
    w <- function(x) compute_weight(x, loss = loss, k = k)
    tau <- function(x) compute_tau(x, loss = loss, k = k)

  } else if (loss == "AH") {
    if (k1.test && k2.test) {
      k1 <- user.args$k1
      k2 <- user.args$k2
      tuning <- "user"
    } else if (tuning.test && tuning == "fixed") {
      k1 <- 1.345
      k2 <- k1
    } else {
      tuning <- "asy"
      tun.res <- select_tuning(res0/sigma0, loss = loss, ini = ini, len = len)
      k1 <- tun.res$k1.sel
      k2 <- tun.res$k2.sel
      if(any(k.test)){
        warning("Tuning parameters are defined but unused. \n  Please provide 'k1' and 'k2' for asymmetric Huber loss.")
      }
    }
    k.obj <- list(k1 = k1, k2 = k2)
    w <- function(x) compute_weight(x, loss = loss, k1 = k1, k2 = k2)
    tau <- function(x) compute_tau(x, loss = loss, k1 = k1, k2 = k2)
  } else if (loss == "AT") {
    if (k1.test && k2.test) {
      k1 <- user.args$k1
      k2 <- user.args$k2
      tuning <- "user"
    } else if (tuning.test && tuning == "fixed") {
      k1 <- 4.685
      k2 <- 4.685
    } else {
      tuning <- "asy"
      tun.res <- select_tuning(res0/sigma0, loss = loss, ini = ini, len = len)
      k1 <- tun.res$k1.sel
      k2 <- tun.res$k2.sel
      if(any(k.test)){
        warning("Tuning parameters are defined but unused. \n  Please provide 'k1' and 'k2' for asymmetric Tukey loss.")
      }
    }
    k.obj <- list(k1 = k1, k2 = k2)
    w <- function(x) compute_weight(x, loss = loss, k1 = k1, k2 = k2)
    tau <- function(x) compute_tau(x, loss = loss, k1 = k1, k2 = k2)
  }

  coeff <- coeff0
  converged <- FALSE

  for (s in 1:itmax) {
    oldcoeff <- coeff
    res <- y - X %*% coeff
    sig.mad <- mad(res)
    W <- w(res / sig.mad)

    XW <- X * sqrt(W)
    yW <- y * sqrt(W)
    qr_result <- qr(XW)
    coeff_new <- qr.coef(qr_result, yW)

    coeff <- as.numeric(coeff_new)

    if (any(is.na(coeff))) {
      coeff <- oldcoeff
      warning("NA values in coefficients, using previous iteration")
      break
    } else if (sum((coeff - oldcoeff)^2) < acc) {
      converged <- TRUE
      break
    }
  }

  fit <- as.numeric(X %*% coeff)
  res <- as.numeric(y - fit)
  sig.mad <- mad(res)
  tau.hat <- tau(res / sig.mad)
  Weights <- w(res / sig.mad)

  XWX <- t(X) %*% diag(Weights) %*% X
  XWX_inv <- tryCatch(
    solve(XWX / sum(Weights)),
    error = function(e) {
      warning("Cannot invert weighted X'X matrix, using generalized inverse")
      MASS::ginv(XWX / sum(Weights))
    }
  )

  cov.mat <- XWX_inv * sig.mad^2 * tau.hat / n
  Std.Error <- sqrt(diag(cov.mat))
  t_values <- coeff / Std.Error

  Coefficients <- cbind(
    Estimate = coeff,
    Std.Error = Std.Error,
    t.value = t_values,
    p.value = 2 * pt(abs(t_values), df = n - p, lower.tail = FALSE)
  )
  rownames(Coefficients) <- colnames(X)
  colnames(Coefficients) <- c("Estimate", "Std. Error", "t value", "Pr(>|t|)")

  names(coeff) <- colnames(X)

  model_obj <- list(
    coefficients = coeff,
    residuals = res,
    fitted.values = fit,
    rank = p,
    n = n,
    df.residual = n - p,
    call = match.call(),
    terms = terms(formula, data = data),
    model = model.frame(formula, data),
    x = X,
    y = y,
    loss.type = loss,
    tuning.method = tuning,
    tuning.parameters = k.obj,
    scale.estimate = sig.mad,
    tau.hat = tau.hat,
    weights = Weights,
    converged = converged,
    iterations = s,
    cov.unscaled = cov.mat / (sig.mad^2 * tau.hat / n),
    sigma = sig.mad,
    coefficients.matrix = Coefficients,
    ini = ini,
    len = len,
    end = end
  )

  class(model_obj) <- c("rlmskew", "list")

  return(model_obj)
}

# summary and print
#' @export
summary.rlmskew <- function(object, ...) {
  result <- list(
    call = object$call,
    coefficients = object$coefficients.matrix,
    residuals = object$residuals,
    resid.summary = quantile(object$residuals, probs = c(0, 0.25, 0.5, 0.75, 1)),
    scale.estimate = object$scale.estimate,
    df.residual = object$df.residual,
    loss.type = object$loss.type,
    tuning.method = object$tuning.method,
    tuning.parameters = object$tuning.parameters,
    converged = object$converged,
    iterations = object$iterations,
    ini = object$ini,
    len = object$len,
    end = object$end,
    weights = object$weights
  )

  class(result) <- "summary.rlmskew"

  return(result)
}

#' @export
print.summary.rlmskew <- function(x, ...) {
  cat("\nCall:\n")
  print(x$call)

  cat("\nResiduals:\n")
  resids5 <- quantile(x$residuals, probs = c(0, 0.25, 0.5, 0.75, 1))
  names(resids5) <- c("Min", "1Q", "Median", "3Q", "Max")
  print(resids5)

  cat("\nCoefficients:\n")
  printCoefmat(x$coefficients,
               digits = max(3, getOption("digits") - 3),
               signif.stars = TRUE,
               has.Pvalue = TRUE,
               cs.ind = 1:2,
               tst.ind = 3,
               P.values = TRUE,
               eps.Pvalue = .Machine$double.eps)

  Weight_model <- x$weights
  if(x$loss.type %in% c("H", "AH")){
    num.outliers <- sum(Weight_model < 0.2)
    inx <- which(Weight_model < 0.2)
    cat("\nWeights:", num.outliers, "observations",
        paste0("c(", paste(inx, collapse = ","), ")"),
        "may be potential outliers with |weight| < 0.2")
  }else{
    num.outliers <- sum(Weight_model < 0.002)
    inx <- which(Weight_model < 0.002)
    cat("\nWeights:", num.outliers, "observations",
        paste0("c(", paste(inx, collapse = ", "), ")"),
        "may be potential outliers with |weight| < 0.002")
  }

  if(sum(inx) > 0){
    resids5.rob <- quantile(x$residuals[-inx], probs = c(0, 0.25, 0.5, 0.75, 1))
    cat("\nResiduals after excluding potential outliers:\n")
    names(resids5.rob) <- c("Min", "1Q", "Median", "3Q", "Max")
    print(resids5.rob)
  }

  cat("\nRobust residual standard error:", round(x$scale.estimate, 4),
      "on", x$df.residual, "degrees of freedom\n")

  if(x$loss.type == "H"){
    loss <- "symmetric Huber loss"
  }else if(x$loss.type == "T"){
    loss <- "symmetric Tukey bisquare loss"
  }else if(x$loss.type == "AH"){
    loss <- "asymmetric Huber loss"
  }else if(x$loss.type == "AT"){
    loss <- "asymmetric Tukey loss"
  }

  if("k" %in% names(x$tuning.parameters)){
    cat("Loss function:", loss, "with k =",
        sprintf("%.3f", x$tuning.parameters[["k"]]))
  }else{
    cat("Loss function:", loss, "with k1 =",
        sprintf("%.3f", x$tuning.parameters[["k1"]]), "and k2 =",
        sprintf("%.3f", x$tuning.parameters[["k2"]]))
  }

  if(x$tuning.method == "asy"){
    tuning.method <- "asymptotic variance criterion;"
    cat("\nTuning method:", tuning.method,
        sprintf("Search range: [%.1f, %.1f] with step length %.1f",
                x$ini, x$end, x$len), "\n")
  }else if(x$tuning.method == "fixed"){
    tuning.method <- "standard fixed;"
    cat("\nTuning method:", tuning.method, "\n")
  }else if(x$tuning.method == "user"){
    tuning.method <- "user-specified;"
    cat("\nTuning method:", tuning.method, "\n")
  }
  invisible(x)
}

#' @export
print.rlmskew <- function(x, ...) {
  cat("Call:\n")
  print(x$call)

  if (x$converged) {
    cat(sprintf("Converged in %d iterations\n", x$iterations))
  }else {
    cat(sprintf("Not converged after %d iterations\n", x$iterations))
  }

  cat("\nCoefficients:\n")
  print(x$coefficients, digits = getOption("digits"))

  cat("\nDegrees of freedom:", x$n, "total;", x$df.residual, "residual\n")
  cat("Scale estimate:", x$scale.estimate, "\n")

  if(x$tuning.method == "asy"){
    tuning.method <- "asymptotic"
  }else if(x$tuning.method == "fixed"){
    tuning.method <- "fixed"
  }else if(x$tuning.method == "user"){
    tuning.method <- "user-specified"
  }

  if(x$loss.type == "H"){
    loss <- "symmetric Huber loss"
  }else if(x$loss.type == "T"){
    loss <- "symmetric Tukey bisquare loss"
  }else if(x$loss.type == "AH"){
    loss <- "asymmetric Huber loss"
  }else if(x$loss.type == "AT"){
    loss <- "asymmetric Tukey loss"
  }

  if("k" %in% names(x$tuning.parameters)){
    cat("Loss function:", loss, "with k =",
        sprintf("%.3f", x$tuning.parameters[["k"]]))
    cat("\nTuning method:", tuning.method, "\n")
  }else{
    cat("Loss function:", loss, "with k1 =",
        sprintf("%.3f", x$tuning.parameters[["k1"]]), "and k2 =",
        sprintf("%.3f", x$tuning.parameters[["k2"]]))
    cat("\nTuning method:", tuning.method, "\n")
  }
}
