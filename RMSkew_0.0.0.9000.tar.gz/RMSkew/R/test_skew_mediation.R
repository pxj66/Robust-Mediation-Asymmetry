#' Test Mediation Effects with Robust Regression
#'
#' Perform hypothesis testing for mediation effects using robust linear regression
#' with asymmetric loss functions.
#'
#' @param formula Model formula using syntax: `y ~ m(mediators, .model = "serial"/"parallel") + x + covariates(vars)`
#' @param data Data frame containing variables
#' @param loss Loss function: "AH", "AT" (default), "H", or "T"
#' @param tuning Tuning method: "asy" (default) or "fixed"
#' @param ini Initial value for optimization (default: 1)
#' @param len Step length for tuning (default: 0.1)
#' @param test Test method: "boot" (default), "sobel", or both
#' @param R Number of bootstrap replicates (default: 1000)
#' @param level Confidence level (default: 0.95)
#' @param type Bootstrap CI type: "perc" (default), "bca", or both
#' @param ... Additional arguments passed to fitting functions
#'
#' @return List with three data frames:
#'   - `ide_ci`: Confidence intervals for indirect effects
#'   - `de_ci`: Confidence intervals for direct effects
#'   - `te_ci`: Confidence intervals for total effects
#'
#' @details This function provides robust mediation analysis suitable for skewed data
#'   or data with outliers. It supports both bootstrap and Sobel test approaches.
#'
#' @seealso \code{\link{fit_skew_mediation}}
#' @export
test_skew_mediation <- function(formula, data, loss = "AT", tuning = "asy",
                                ini = 1, len = 0.1, test = c("sobel", "boot"),
                                R = 1000, level = 0.95,
                                type = c("perc", "bca"),...){
  type = match.arg(type, several.ok = TRUE)
  test = match.arg(test, several.ok = TRUE)
  fit <- fit_skew_mediation(formula = formula, data = data, loss = loss,
                            tuning = tuning, ini = ini, len = len, ...)
  ide_sobel_ci <- if("sobel" %in% test) sobel.ci(fit, level)

  tuning_set <- fit$tuning_set
  Result_boot <- boot(data = data,
              boot_skew_mediation(formula = formula, loss = loss,
                                  tuning = tuning, ini = ini, len = len,
                                  tuning_set = tuning_set), R = R)
  pathname_indirect <- fit$coeff_indirect[["path"]]
  pathname_direct <- fit$coeff_direct[["path"]]
  pathname_total <- fit$coeff_total[["path"]]
  #number of indirect, direct and total paths
  n_ide <- nrow(fit$coeff_indirect)
  n_de <- nrow(fit$coeff_direct)
  n_total <- nrow(fit$coeff_total)
  n <- n_ide + n_de + n_total
  #bootstrap confidence interval
  Result_boot_ci <- lapply(1:n, function(i){
    ci_boot <- boot.ci(Result_boot, conf = level, type = type, index = i)
    perc_l <- ci_boot[["percent"]][4]
    perc_r <- ci_boot[["percent"]][5]
    bca_l <- ci_boot[["bca"]][4]
    bca_r <- ci_boot[["bca"]][5]
    data.frame(perc_l = perc_l, perc_r = perc_r, bca_l = bca_l, bca_r = bca_r)
  })
  df_boot_ci <- do.call(rbind, Result_boot_ci)
  eff_boot <- colMeans(Result_boot$t)
  #confidence interval of indirect effect
  ide_boot_ci <- df_boot_ci[seq.int(n_ide),]
  ide_t0 <- Result_boot$t0[seq.int(n_ide)]
  ide_boot_t <- eff_boot[seq.int(n_ide)]
  ide_ci <- cbind(pathname_indirect,ide_t0, ide_boot_t,ide_sobel_ci, ide_boot_ci)
  ide_ci <- as.data.frame(lapply(ide_ci, function(x){
    if(is.numeric(x)) round(x, digits = 6) else x
  }))
  colnames(ide_ci)[seq.int(3)] <- c("path", "ide_data", "ide_boot")
  #confidence interval of direct effect
  index_de <- seq.int(from = n_ide + 1, to = n_ide + n_de)
  de_boot_ci <- df_boot_ci[index_de, ]
  de_ztest_ci <- ztest.ci(fit = fit, level = level, "de")
  de_t0 <- Result_boot$t0[index_de]
  de_boot_t <- eff_boot[index_de]
  de_ci <- cbind(pathname_direct,de_t0, de_boot_t,de_ztest_ci, de_boot_ci)
  de_ci <- as.data.frame(lapply(de_ci, function(x){
    if(is.numeric(x)) round(x, digits = 6) else x
  }))
  colnames(de_ci)[seq.int(3)] <- c("path", "de_data", "de_boot")
  #confidence interval of total effect
  index_te <- seq.int(from = n_ide + n_de + 1, to = n_ide + n_de + n_total)
  te_boot_ci <- df_boot_ci[index_te, ]
  te_ztest_ci <- ztest.ci(fit = fit, level = level, "te")
  te_t0 <- Result_boot$t0[index_te]
  te_boot_t <- eff_boot[index_te]
  te_ci <- cbind(pathname_direct,te_t0, te_boot_t,te_ztest_ci, te_boot_ci)
  te_ci <- as.data.frame(lapply(te_ci, function(x){
    if(is.numeric(x)) round(x, digits = 6) else x
  }))
  colnames(te_ci)[seq.int(3)] <- c("path", "te_data", "te_boot")
  return(list(ide_ci= ide_ci, de_ci = de_ci, te_ci = te_ci))
}

#' boot_skew_mediation
#' @keywords internal
#' @noRd
boot_skew_mediation <- function(formula, loss, tuning, ini, len, tuning_set, ...){
  function(d, i){
    d0 <- d[i, ]
    fit0 <- fit_skew_mediation(formula = formula, data = d0, loss = loss,
                               tuning_set = tuning_set, ...)
    IDE <- fit0$coeff_indirect[["IDE"]]
    DE <- fit0$coeff_direct[["DE"]]
    TE <- fit0$coeff_total[["TE"]]
    c(IDE, DE, TE)
  }
}

#' Sobel-type confidence interval
#' @keywords internal
#' @noRd
sobel.ci <- function(fit, level){
  ide <- fit$coeff_indirect[["IDE"]]
  se_sobel <- fit$coeff_indirect[["St.Err.Sobel"]]
  sobel_l <- ide - qnorm((1 + level)/2) * se_sobel
  sobel_r <- ide + qnorm((1 + level)/2) * se_sobel
  data.frame(sobel_l = sobel_l, sobel_r = sobel_r)
}

#' Z-test confidence interval
#' @keywords internal
#' @noRd
ztest.ci <- function(fit, level, class = "te"){
  if(class == "te"){
    eff <- fit$coeff_total[["TE"]]
    se <- fit$coeff_total[["St.Err"]]
  }else{
    eff <- fit$coeff_direct[["DE"]]
    se <- fit$coeff_direct[["St.Err"]]
  }
  ztest_l <- eff - qnorm((1 + level)/2) * se
  ztest_r <- eff - qnorm((1 + level)/2) * se
  data.frame(ztest_l = ztest_l, ztest_r = ztest_r)
}


