#' @title Predictors of Cognitive Function in Midlife Americans:
#' The Role of Light Physical Activity and Perceived Control.
#' 
#' @description A cross-sectional dataset examining psychosocial and behavioral
#' correlates of cognitive function among midlife American adults.
#' This dataset originates from the Midlife in the United States (MIDUS) study
#' and investigates associations between light physical activity, perceived control,
#' and cognitive performance while adjusting for key demographic and socioeconomic
#' covariates.
#' 
#' @docType data
#' @keywords datasets, cognitive function, physical activity, perceived control, MIDUS
#' @name LPACOG
#' @usage data("LPACOG")
#' @format A data frame with 3,252 observations (rows) and 10 variables (columns):
#' \describe{
#'  \item{cf}{Cognitive function composite score measured using the
#' Brief Test of Adult Cognition by Telephone (BTACT) battery. 
#' The score integrates performance on episodic memory and executive function tasks.
#' Higher scores indicate better cognitive performance.}
#'  \item{lpa}{Light physical activity index, calculated from
#' self-reported frequencies of light-intensity occupational, household,
#' and leisure activities during both summer and winter months.}
#'  \item{pc}{Perceived control scale combining two dimensions:
#' personal mastery (sense of agency) and perceived constraints (lack of control).
#' Higher scores indicate greater perceived control over life circumstances.}
#'  \item{age}{Age in years at assessment (range: 32–84; M = 56, SD = 12.0).}
#'  \item{sex}{Biological sex: "Female" (n = 1,760, 54.1%) or
#' "Male" (n = 1,492, 45.9%)}
#'  \item{race}{Racial identification: "White" (n = 3,027, 93.1%) or
#' "Nonwhite" (n = 225, 6.9%). Nonwhite category includes Black, Asian,
#' Native American, and multiracial individuals.}
#'  \item{educ}{Educational attainment in years, coded ordinally:
#' 3.5 = Some grade school (1–6 years); 7.5 = Junior high school (7–8 years);
#' 10.5 = Some high school (9–12 years, no diploma); 12 = High school diploma or GED;
#' 13.5 = 1–2 years of college; 15 = 3+ years of college or associate degree;
#' 16 = Bachelor's degree; 16.5 = Some graduate school; 19 = Master's degree;
#' 22 = Doctoral or professional degree (MD, JD, PhD, etc.).}
#'  \item{inc}{Annual household income in US dollars (range: $0–$300,000;
#' median = $60,250; mean = $73,653; SD = $60,275). Values are adjusted for
#' inflation to a common reference year.}
#'  \item{pses}{Perceived socioeconomic status measured on a ladder scale
#' where participants rate their social standing relative to others.}
#'  \item{limit}{Functional limitations index assessing difficulties in
#' activities of daily living. Higher scores indicate more limitations.}
#' }
#' 
#' @details The dataset is well-suited for investigating moderating and mediating pathways
#' between lifestyle factors (light physical activity), psychosocial resources
#' (perceived control), and cognitive aging. 
#' @source Midlife in the United States (MIDUS) Study, Wave 2 (2004–2006).
#' Data were accessed through the Inter-university Consortium for Political and
#' Social Research (ICPSR). Documentation available at:
#' \url{https://www.icpsr.umich.edu/web/ICPSR/series/203}.
#' 
#' @references 
#' Hamm, J.M., Lachman, M.E., Duggan, K.A., Mogle, J.A., McGrath, R.,
#' Parker, K., Klepacz, L.M., 2025. When and how perceived control buffers
#' against cognitive declines: A moderated mediation analysis. Psychology
#' and Aging 40, 39–53.
#' 
#' Peng, X., Wang, W. W., Zhao, S., 2025. Robust mediation analysis with asymmetric
#' data. Submitted.
#' 
#' Ryff, C., Almeida, D., Ayanian, J., Binkley, N., Carr, D.S., Coe, C., Davidson,
#' R., Grzywacz, J., Karlamangla, A., Krueger, R., Lachman, M., Love,
#' G., Mailick, M., Mroczek, D., Radler, B., Seeman, T., Sloan, R., Thomas,
#' D., Weinstein, M., Williams, D., 2019. Midlife in the united states (midus 3), 2013-2014. 
#' \doi{10.3886/ICPSR36346.v7}.
NULL