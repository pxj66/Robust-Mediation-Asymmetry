#' Fit Mediation Models with Robust Asymmetric Loss Functions
#'
#' @description
#' This function fits mediation models using robust linear regression with
#' asymmetric loss functions, providing robust estimation for skewed
#' or asymmetric data.
#' It supports both serial (sequential) and parallel (multiple) mediation models.
#'
#' @details
#' The function implements robust mediation analysis through the following steps:
#' 1. Extracts mediation model structure from the formula
#' 2. Fits regression equations for mediator(s)-outcome relationships using \code{rlmskew}
#' 3. Computes indirect, direct, and total effects
#' 4. Calculates Sobel-type standard errors for indirect effects
#'
#' The method is particularly useful when data exhibit skewness or when traditional
#' normality assumptions are violated.
#'
#' @param formula A formula specifying the mediation model.
#' Use \code{y ~ x + m(mediator1, mediator2, ...) + covariates(covariate1, covariate2, ...)}
#' for proper specification.
#' Example: \code{m(mediator1, mediators, .model = "parallel")} for parallel mediation,
#'   or \code{m(mediator1, mediators, .model = "serial")} specify serial paths explicitly.
#' @param data A data frame containing the variables in the model.
#' @param loss Character string specifying the loss function. Options include:
#'   \describe{
#'     \item{"AT"}{Asymmetric Tukey loss (default)}
#'     \item{"AH"}{Asymmetric Huber loss}
#'     \item{"H"}{Symmetric Huber loss}
#'     \item{"T"}{Symmetric Tukey's biweight loss}
#'   }
#' @param tuning Character string or list specifying tuning parameters. Options:
#'   \describe{
#'     \item{"asy"}{Automatic tuning based on asymptotic variance criterion (default)}
#'     \item{"fixed"}{Huber loss uses 1.345. Tukey loss uses 4.685.}
#'   }
#' @param ini Numeric or character specifying initial values. Default is 1.
#' @param len Step length for optimization. Default is 0.1.
#' @param tuning_set A list (optional) of pre-computed tuning parameters for reproducibility.
#'   Should contain elements \code{tun_yx}, \code{tun_ymx}, and \code{tun_mx}.
#' @param ... Additional parameters passed to \code{\link{rlmskew}}, including:
#'   \describe{
#'     \item{k}{Tuning parameter for Huber/Tukey loss}
#'     \item{k1, k2}{Asymmetric tuning parameters for asymmetric Huber/Tukey loss}
#'   }
#'
#' @return An object of class \code{"skew_mediation"} containing:
#'   \describe{
#'     \item{coeff_indirect}{Data frame of indirect effects with Sobel test results}
#'     \item{coeff_direct}{Data frame of direct effects}
#'     \item{coeff_total}{Data frame of total effects}
#'     \item{coeff_subpath}{List of coefficients for each sub-path}
#'     \item{fit_yx}{Fitted model for Y ~ X (total effect)}
#'     \item{fit_ymx}{Fitted model for Y ~ M + X (direct effect)}
#'     \item{fit_mx}{List of fitted models for each M ~ X}
#'     \item{call}{Function call}
#'     \item{formula_fit}{Processed formula structure}
#'     \item{tuning_set}{Tuning parameters used}
#'   }
#'
#' @section Model Specification:
#' For parallel mediation (multiple mediators independently affecting the outcome):
#' \preformatted{
#' fit_skew_mediation(y ~ x + m(m1, m2, .model = "parallel"), data)
#' }
#'
#' For serial mediation (mediators in sequence):
#' \preformatted{
#' fit_skew_mediation(y ~ x + m(m1, m2, .model = "serial"), data, model = "serial")
#' }
#'
#' The function automatically detects the model type based on the formula structure.
#'
#' @section Interpretation:
#' - **Indirect Effect (IDE)**: Effect of X on Y through mediator(s)
#' - **Direct Effect (DE)**: Effect of X on Y not mediated by M
#' - **Total Effect (TE)**: Total effects of X on Y
#' - **Sobel Test**: Tests significance of indirect effects
#'
#' @examples
#' data(LPACOG)
#'
#' # Example 1: Simple mediation with asymmetric Tukey loss
#' formula1 <- cf ~ m(lpa) + pc
#' fit1 <- fit_skew_mediation(formula1, data = LPACOG, loss = "AT")
#' fit1
#'
#' # Example 2: Parallel mediation with two mediators
#' formula2 <- cf ~ pc + m(lpa, limit) + covariates(age, sex, inc, educ)
#' fit2 <- fit_skew_mediation(formula2, data = LPACOG, loss = "H", tuning = "asy")
#' fit2
#'
#' # Example 3: Serial mediation with pre-specified tuning parameters
#' formula3 <- cf ~ pc + m(lpa, limit) + covariates(age, sex, inc, educ)
#' fit3 <- fit_skew_mediation(formula3, data = LPACOG)
#' fit3
#'
#' # Use the same tuning for reproducibility
#' fit3_repl <- fit_skew_mediation(formula3, data = LPACOG,
#'                                 tuning_set = fit3$tuning_set)
#'
#' # Extract results
#' indirect_effects <- fit3_repl$coeff_indirect
#' direct_effects <- fit3_repl$coeff_direct
#'
#'
#' @references
#' Alfons, A., Ate\c{s}, N.Y., & Groenen, P.J. (2022). A robust bootstrap test for
#' mediation analysis. *Organizational Research Methods*, 25, 591–617.
#'
#' Peng, X., Wang W.W., & Zhao S.L. (2026). Robust mediation analysis with asymmetric
#' data. *Submitted*.
#'
#' @seealso
#' \code{\link{rlmskew}} for the underlying robust regression function.
#' \code{\link{summary.skew_mediation}} for summary methods.
#'
#' @export
fit_skew_mediation <- function(formula, data, loss = "AT", tuning = "asy",
                               ini = 1, len = 0.1, tuning_set = NULL,...){
  formula_fit <- extract_mediation_formula(formula = formula, data = data)
  call <- match.call()
  model <- formula_fit$model
  data <- formula_fit$data
  y <- formula_fit$y
  m <- formula_fit$m
  x <- formula_fit$x
  p_x <- length(x)
  covariates <- formula_fit$covariates
  formula_mx <- formula_fit$formula_mx
  formula_yx <- formula_fit$formula_yx
  formula_ymx <- formula_fit$formula_ymx
  formula_set <- c(formula_mx, formula_ymx)
  #fit various regression equations for mediation
  if(is.null(tuning_set)){
    fit_mx <- lapply(formula_mx, function(formula){
      rlmskew(formula = formula, data = data, loss = loss, ini = ini, len = len, ...)
    })
    fit_ymx <- list(y = rlmskew(formula = formula_ymx[[1]], data = data,
                                loss = loss, ini = ini, len = len, ...))
    names(fit_ymx) <- y
    fit_yx <- list(y = rlmskew(formula = formula_yx[[1]], data = data,
                               loss = loss, ini = ini, len = len, ...))
    names(fit_yx) <- y
    fit_set <- c(fit_mx, fit_ymx)
    #save tuning parameters
    tun_mx <- lapply(m, function(index_m){
      fit_mx[[index_m]][["tuning.parameters"]]
    })
    names(tun_mx) <- m
    tun_ymx <- fit_ymx[[y]][["tuning.parameters"]]
    tun_yx <- fit_yx[[y]][["tuning.parameters"]]
    tuning_set <- list(tun_yx = tun_yx, tun_ymx = tun_ymx, tun_mx = tun_mx)
  }else{
    if(loss %in% c("H", "T")){
      k.yx <- tuning_set$tun_yx[["k"]]
      k.ymx <- tuning_set$tun_ymx[["k"]]
      k.mx <- tuning_set$tun_mx
      fit_mx <- mapply(function(formula, k){
        rlmskew(formula = formula, data = data, loss = loss, ini = ini, len = len,
                k = k[["k"]])
      }, formula_mx, k.mx, SIMPLIFY = FALSE)
      fit_ymx <- list(y = rlmskew(formula = formula_ymx[[1]], data = data,
                                  loss = loss, ini = ini, len = len,
                                  k = k.ymx))
      names(fit_ymx) <- y
      fit_yx <- list(y = rlmskew(formula = formula_yx[[1]], data = data,
                                 loss = loss, ini = ini, len = len,
                                 k = k.yx))
      names(fit_yx) <- y
      fit_set <- c(fit_mx, fit_ymx)
    }else{
      k.yx <- tuning_set$tun_yx
      k.ymx <- tuning_set$tun_ymx
      k.mx <- tuning_set$tun_mx
      fit_mx <- mapply(function(formula, k){
        rlmskew(formula = formula, data = data, loss = loss, ini = ini, len = len,
                k1 = k[["k1"]], k2 = k[["k2"]])
      }, formula_mx, k.mx, SIMPLIFY = FALSE)
      fit_ymx <- list(y = rlmskew(formula = formula_ymx[[1]], data = data,
                                  loss = loss, ini = ini, len = len,
                                  k1 = k.ymx[["k1"]], k2 = k.ymx[["k2"]]))
      names(fit_ymx) <- y
      fit_yx <- list(y = rlmskew(formula = formula_yx[[1]], data = data,
                                 loss = loss, ini = ini, len = len,
                                 k1 = k.yx[["k1"]], k2 = k.yx[["k2"]]))
      names(fit_yx) <- y
      fit_set <- c(fit_mx, fit_ymx)
    }
  }
  #identify indirect paths for serial or parallel mediation model
  if(model == "serial"){
    path_indirect <- lapply(1:length(m), function(t){
      #identify possible combinations of paths that contain mediators
      m_combinations <- combn(m, t, simplify = FALSE)
      #creat complete indirect paths
      path_full <- lapply(m_combinations, function(s) {
        sapply(x, function(x_active){
          paste0(x_active, " -> ", paste(s, collapse = " -> "), " -> ", y)
        })
      })
      unlist(path_full, use.names = FALSE)
    })
    #standardize indirect path to make it a unnamed character vector
    path_indirect <- unlist(path_indirect, use.names = FALSE)
  }else{
    #identify possible combinations of mediators and independent variables
    mx_combinations <- expand.grid(x = x, m = m, stringsAsFactors = FALSE)
    #creat complete indirect paths
    path_indirect <- paste0(mx_combinations$x, " -> ", mx_combinations$m, " -> ", y)
  }
  #extract sub-paths for each indirect path
  subpath_indirect <- lapply(path_indirect, exact_binary_subpath)
  coeff_subpath <- lapply(subpath_indirect, function(subpath){
    extract_coef_subpath(fit_set, subpath)})
  coeff_indirect <- lapply(coeff_subpath, extract_indirect_effect)
  coeff_indirect <- do.call(rbind, coeff_indirect)
  ##extract direct effect
  coeff_direct <- summary(fit_ymx[[1]])[["coefficients"]][x, , drop = FALSE]
  colnames(coeff_direct) <- c("DE", "St.Err", "t_value", "p_value")
  rownames(coeff_direct) <- NULL
  path_direct <- sapply(x, function(t){
    paste(t, " -> ", y, "|", paste0(m, collapse = ","), sep = "")
  })
  names(path_direct) <- NULL
  path_direct_df <- data.frame(path = path_direct, stringsAsFactors = FALSE)
  coeff_direct <- cbind(path_direct_df, coeff_direct)
  ##extract total effect
  coeff_total <- summary(fit_yx[[1]])[["coefficients"]][x, , drop = FALSE]
  colnames(coeff_total) <- c("TE", "St.Err", "t_value", "p_value")
  rownames(coeff_total) <- NULL
  path_total <- sapply(x, function(t){
    paste(x, " -> ", y, sep = "")
  })
  names(path_total) <- NULL
  path_total_df <- data.frame(path = path_total, stringsAsFactors = FALSE)
  coeff_total <- cbind(path_total_df, coeff_total)
  result <- list(coeff_indirect = coeff_indirect, coeff_direct = coeff_direct,
                 coeff_total = coeff_total, coeff_subpath = coeff_subpath,
                 fit_yx = fit_yx, fit_ymx = fit_ymx, fit_mx = fit_mx,
                 call = call, formula_fit = formula_fit, tuning_set = tuning_set)
  class(result) <- c("skew_mediation", "list")
  result
}


#' Extract Binary Sub-paths from Indirect Path
#'
#' @description
#' Decomposes an indirect path (e.g., "x -> m1 -> y") into its constituent
#' binary sub-paths (e.g., "x -> m1" and "m1 -> y").
#'
#' @details
#' This internal function is used by \code{\link{fit_skew_mediation}} to
#' break down complex mediation paths for coefficient extraction.
#'
#' @param path Character string specifying the indirect path, with variables
#'   separated by " -> " (e.g., "x -> m1 -> m2 -> y").
#'
#' @return A data frame with columns:
#'   \describe{
#'     \item{response}{Response variable for each sub-path}
#'     \item{predictor}{Predictor variable for each sub-path}
#'     \item{subpath}{Full sub-path specification}
#'     \item{path}{Original indirect path}
#'   }
#'
#' @examples
#' \dontrun{
#' # Decompose a three-variable path
#' exact_binary_subpath("pc -> lpa -> cf")
#' # Returns:
#' #   response   predictor   subpath     path
#' # 1     lpa       pc       pc -> lpa   pc -> lpa -> cf
#' # 2      cf      lpa       lpa -> cf   pc -> lpa -> cf
#' }
#' @keywords internal
exact_binary_subpath <- function(path){
  names_var <- unlist(strsplit(path, " -> "))
  subpaths <- paste(names_var[-length(names_var)], names_var[-1], sep = " -> ")
  predictors <- names_var[-length(names_var)]
  responses <- names_var[-1]
  data.frame(response = responses, predictor = predictors,
             subpath = subpaths, path = path,stringsAsFactors = FALSE)
}

#' Compute Sobel-type standard error
#'
#' @description Compute Sobel-type standard error based on delta method.
#'
#' @param a_hat coefficient estimator vector.
#' @param a_se standard error vector of coefficient.
#'
#' @return Sobel-type standard error.
#' @export
compute_se_sobel <- function(a_hat, a_se){
  #record the number of a_hat
  n <- length(a_hat)
  #check length of a_hat and a_se
  if(length(a_se) != n){
    stop("The lengths of a_hat and a_se are not the same")
  }
  #record the location of standard error
  index_se <- seq.int(length.out = n)
  #compute Sobel-type standard error
  sqrt(sum(sapply(index_se, function(i){
    (prod(c(a_hat[-i], a_se[i])))^2
  })))
}

#' Extract coefficients and standard errors for each sub-path
#'
#' @description Extract coefficients and standard error for each sub-path.
#'
#' @param fit_set A list contains fitting results. The name of each element of
#' \code{fit_set} is governed by response variable.
#' @param subpath_set A data.frame contains response variable and predictor of
#' each binary sub-path.
#' @return A data.frame contains coefficient and its standard error for each
#' indirect path.
#' @keywords internal
extract_coef_subpath <- function(fit_set, subpath_set){
  df <- data.frame(subpath_set, stringsAsFactors = FALSE)
  n <- nrow(df)
  name_path <- df[["path"]][1]
  result <- lapply(seq.int(n), function(i){
    name_subpath <- df[i, "subpath"]
    #index of response of the sub-path
    index_response <- df[i, "response"]
    #index of predictor of the sub-path
    index_predictor <- df[i, "predictor"]
    #coefficients matrix of each sub-path
    coef_matrix <- summary(fit_set[[index_response]])[["coefficients"]]
    coef_subpath <- coef_matrix[index_predictor,]
    data.frame(path = name_path, subpath = name_subpath,
               coef = coef_subpath[1], se = coef_subpath[2],
               tvalue = coef_subpath[3], pvalue = coef_subpath[4])
  })
  do.call(rbind, c(result, make.row.names = FALSE))
}

#' Extract indirect effect and its Sobel-type standard error
#'
#' @description Extract indirect effect and its Sobel-type standard error.
#' @param test_subpath A data.frame contains the coefficients and
#' @keywords internal
extract_indirect_effect <- function(test_subpath){
  df <- data.frame(test_subpath, stringsAsFactors = FALSE)
  name_path <- df[["path"]][1]
  ide <- prod(df[["coef"]])
  se_sobel <- compute_se_sobel(df[["coef"]], df[["se"]])
  zvalue <- ide / se_sobel
  pvalue <- 2 * (1 - pnorm(abs(zvalue)))
  data.frame(path = name_path, IDE = ide, St.Err.Sobel = se_sobel, t_value = zvalue,
             p_value = pvalue, stringsAsFactors = FALSE)
}

#' summary and print
#' @export
print.skew_mediation <- function(x, ...){
  object <- x
  cat("\nCall:\n")
  print(object$call)

  cat("\nIndirect Path:\n")
  print(object$coeff_indirect)

  cat("\nDirect Path:\n")
  print(object$coeff_direct)

  cat("\nTotal Path:\n")
  print(object$coeff_total)
}

