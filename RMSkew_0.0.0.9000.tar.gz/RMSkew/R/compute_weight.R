#' @title Weight function for asymmetric Huber and Tukey loss
#'
#' @description
#' Computes the weight \eqn{w(x) = \psi(x)/x} based on asymmetric Huber or Tukey loss.
#'
#' @details
#' The asymmetric Huber weight function is defined as:
#' \itemize{
#'  \item If \eqn{x < - k_1} \deqn{w(x) = -\frac{k_1}{x}}
#'  \item If \eqn{- k_1\le x \le k_2} \deqn{w(x) = 1}
#'  \item If \eqn{x > k_2} \deqn{w(x) = \frac{k_2}{x}}
#' }
#'
#' The asymmetric Tukey weight function is defined as:
#' \itemize{
#'  \item If \eqn{x < - k_1} or \eqn{x > k_2} \deqn{w(x) = 0}
#'  \item If \eqn{- k_1\le x < 0} \deqn{w(x) = 1 - \frac{2 x^2}{k_1^2} + \frac{x^4}{k_1^4}}
#'  \item If \eqn{0 \le x \le k_2} \deqn{w(x) = 1 - \frac{2 x^2}{k_2^2} + \frac{x^4}{k_2^4}}
#' }
#'
#' For the asymmetric Huber loss, residuals within the thresholds \eqn{[-k_1, k_2]}
#' are assigned unit weight (full influence), while the weight of residuals
#' beyond the thresholds decreases proportionally to \eqn{1/|x|}.
#' For the asymmetric Tukey loss, residuals within the thresholds \eqn{[-k_1, k_2]}
#' are assigned smoothly decreasing weight as \eqn{|x|} moves away from 0,
#' while residuals beyond the thresholds receive zero weight (no influence).
#'
#' @param x Numeric vector of residuals or input values.
#' @param loss Character string specifying the loss function type.
#'             Must be either "AH" (asymmetric Huber) or "AT" (asymmetric Tukey).
#' @param k1 Left tuning parameter (positive). Controls threshold for negative outliers.
#' @param k2 Right tuning parameter (positive). Controls threshold for positive outliers.
#' @param k Tuning parameter for symmetric Huber or Tukey loss.
#'
#' @return Numeric vector of weight values between 0 and 1.
#'
#' @seealso
#' \code{\link{psi}} for the corresponding psi function.
#'
#' @export
#'
#' @examples
#' x <- seq(-5, 5, 0.01)
#' w.AH <- compute_weight(x, loss = "AH", 1.345, 2)
#' w.AT <- compute_weight(x, loss = "AT", 3, 4.685)
#' plot(x, w.AT, type = "l", col = "red")
#' lines(x, w.AH, type = "l")
#' legend("topleft", legend = c("AH (1.345, 2)", "AT (3, 4.685)"), fill = c("black", "red"))
compute_weight <- function(x, loss = c("H", "AH", "T", "AT"), k1 = NULL, k2 = NULL, k = NULL){
  w <- numeric(length(x))
  if(loss == "AH"){
    neg <- x < -k1
    pos <- x > k2
    w[neg] <- - k1 / x[neg]
    w[pos] <- k2 / x[pos]
    w[!(neg | pos)] <- 1
  }else if(loss == "H"){
    inx <- abs(x) > k
    w[inx] <- k / abs(x[inx])
    w[!inx] <- 1
  }
  else if(loss == "AT"){
    neg_out <- x < -k1
    neg_in <- x < 0 & (!neg_out)
    pos_out <- x > k2
    pos_in <- x >= 0 & (!pos_out)
    w[neg_out] <- 0
    w[pos_out] <- 0
    w[neg_in] <- (1 - (x[neg_in] / k1)^2)^2
    w[pos_in] <- (1 - (x[pos_in] / k2)^2)^2
  }else if(loss == "T"){
    inx <- abs(x) > k
    w[!inx] <- (1 - (x[!inx] / k)^2)^2
    w[inx] <- 0
  }
  return(w)
}
