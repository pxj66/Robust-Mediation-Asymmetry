#' @title psi function for asymmetric Huber and Tukey loss
#'
#' @description
#' Computes the psi (derivative) function for the asymmetric Huber or Tukey loss.
#'
#' @details
#' Asymmetric Huber psi function (\code{loss = "AH"}):
#'
#' \itemize{
#'  \item If \eqn{x < -k_1} \deqn{\psi(x) = -k_1}
#'  \item If \eqn{-k_1 \le x \le k_2} \deqn{\psi(x) = x}
#'  \item If \eqn{x > k_2} \deqn{\psi(x) = k_2}
#' }
#'
#' Asymmetric Tukey psi function (\code{loss = "AT"}):
#'
#' \itemize{
#' \item If \eqn{x < -k_1} or \eqn{x > k_2} \deqn{\psi(x) = 0}
#' \item If \eqn{-k_1 \le x < 0} \deqn{\psi(x) = x - \frac{2 x^3}{k_1^2} + \frac{x^5}{k_1^4}}
#' \item If \eqn{0 \le x < k_2} \deqn{\psi(x) = x - \frac{2 x^3}{k_2^2} + \frac{x^5}{k_2^4}}
#' }
#'
#' where \eqn{k_1 > 0} and \eqn{k_2 > 0} are tuning parameters controlling
#' sensitivity to negative and positive outliers respectively.
#' When \eqn{k_1 = k_2 = k}, these asymmetric psi functions reduce to their
#' classical symmetric counterparts.
#'
#' @param x Numeric vector of residuals or input values.
#' @param loss Character string specifying the loss function type.
#'             Must be either "AH" (asymmetric Huber) or "AT" (asymmetric Tukey).
#' @param k1 Left tuning parameter (positive).
#' @param k2 Right tuning parameter (positive).
#' @param k Tuning parameter for symmetric Huber or Tukey loss.
#'
#' @export
#' @return Numeric vector of the same length as `x` containing psi function values.
#'
#' @references
#' Peng, X., Wang, W. W., & Zhao, S. (2025). Robust Mediation Analysis with Asymmetric Data.
#' \emph{Submitted to MBR}.
#'
#' @author Xiujin Peng <pxiujin@163.com>
#'
#' @examples
#' x <- seq(-5, 5, 0.01)
#' psi_AH <- psi(x, loss = "AH", k1 = 1.345, k2 = 2)
#' psi_AT <- psi(x, loss = "AT", k1 = 3, k2 = 4.685)
#' plot(x, psi_AH, type = "l", ylab = "psi_values", main = "Asymmetric Huber and Tukey psi function")
#' lines(x, psi_AT, col = "red")
#' legend("topleft", legend = c("AH (1.345, 2)", "AT (3, 4.685)"), fill = c("black", "red"))
psi <- function(x, loss = c("H", "AH", "T", "AT"), k1 = NULL, k2 = NULL, k = NULL){
  psiv <- numeric(length(x))
  if(loss == "AH"){
    neg <- x < -k1
    pos <- x > k2
    psiv[neg] <- -k1
    psiv[pos] <- k2
    psiv[!(neg | pos)] <- x[!(neg | pos)]
  }else if(loss == "AT"){
    neg_out <- x < -k1
    neg_in <- (!neg_out) & x < 0
    pos_out <- x > k2
    pos_in <- (!x < 0) & (!pos_out)
    psiv[neg_out] <- 0
    psiv[pos_out] <- 0
    psiv[neg_in] <- x[neg_in] - 2 * x[neg_in]^3 / k1^2 + x[neg_in]^5 / k1^4
    psiv[pos_in] <- x[pos_in] - 2 * x[pos_in]^3 / k2^2 + x[pos_in]^5 / k2^4
  }else if(loss == "H"){
    inx <- abs(x) <= k
    psiv[inx] <- x[inx]
    psiv[!inx] <- sign(x[!inx]) * k
  }else if(loss == "T"){
    inx <- abs(x) <= k
    psiv[inx] <- x[inx] - 2 * x[inx]^3 / k^2 + x[inx]^5 / k^4
    psiv[!inx] <- 0
  }
  return(psiv)
}
