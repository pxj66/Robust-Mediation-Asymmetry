#' @title Derivative of Asymmetric Huber and Tukey Psi Functions
#'
#' @description
#' Computes the derivative of the asymmetric Huber or Tukey psi function.
#'
#' @details
#' The derivative of the asymmetric Huber psi function is defined as
#' \itemize{
#'  \item If \eqn{x < -k_1} or \eqn{x > k_2} \deqn{\psi^\prime(x) = 0}
#'  \item If \eqn{-k_1 \le x \le k_2} \deqn{\psi^\prime(x) = 1}
#' }
#'
#' The derivative of the asymmetric Tukey psi function is defined as
#' \itemize{
#'  \item If \eqn{x < -k_1} or \eqn{x > k_2} \deqn{\psi^\prime(x) = 0}
#'  \item If \eqn{-k_1 \le x < 0} \deqn{\psi^\prime(x) = 1 - \frac{6x^2}{k_1^2} + \frac{5x^4}{k_1^4}}
#'  \item If \eqn{0 \le x \le k_2} \deqn{\psi^\prime(x) = 1 - \frac{6x^2}{k_2^2} + \frac{5x^4}{k_2^4}}
#' }
#'
#' @param x Numeric vector of residuals or input values.
#' @param loss Character string specifying the loss function type.
#'             Must be either "AH" (asymmetric Huber) or "AT" (asymmetric Tukey).
#' @param k1 Left tuning parameter (positive). Controls threshold for negative outliers.
#' @param k2 Right tuning parameter (positive). Controls threshold for positive outliers.
#' @param k Tuning parameter for symmetric Huber or Tukey loss.
#'
#' @return Numeric vector of derivative values.
#'         For Huber: returns 0 or 1.
#'         For Tukey: returns values that may be negative in the redescending region.
#'
#' @seealso
#' \code{\link{psi}} for the base psi function.
#'
#' @export
#'
#' @examples
#' x <- c(-5, -1, 0, 1.5, 3, 5)
#' Dpsi(x, loss = "AH", k1 = 1.345, k2 = 2)
#' Dpsi(x, loss = "AT", k1 = 3, k2 = 4.685)
Dpsi <- function(x, loss = c("AH", "AT", "T", "H"), k1 = NULL, k2 = NULL, k = NULL){
  Dpsiv <- numeric(length(x))
  if (loss == "AH"){
    neg <- x < -k1
    pos <- x > k2
    Dpsiv[neg | pos] <- 0
    Dpsiv[!(neg | pos)] <- 1
  }else if(loss == "AT"){
    neg_out <- x < -k1
    neg_in <- (x < 0) & (!neg_out)
    pos_out <- x > k2
    pos_in <- (x >=0) & (!pos_out)
    Dpsiv[neg_out] <- 0
    Dpsiv[pos_out] <- 0
    Dpsiv[neg_in] <- 1 - 6 * x[neg_in]^2 / k1^2 + 5 * x[neg_in]^4 / k1^4
    Dpsiv[pos_in] <- 1 - 6 * x[pos_in]^2 / k2^2 + 5 * x[pos_in]^4 / k2^4
  }else if(loss == "H"){
    inx <- abs(x) <= k
    Dpsiv[inx] <- 1
    Dpsiv[!inx] <- 0
  }else if(loss == "T"){
    inx <- abs(x) <= k
    Dpsiv[inx] <- 1 - 6 * x[inx]^2 / k^2 + 5 * x[inx]^4 / k^4
    Dpsiv[!inx] <- 0
  }
  return(Dpsiv)
}
